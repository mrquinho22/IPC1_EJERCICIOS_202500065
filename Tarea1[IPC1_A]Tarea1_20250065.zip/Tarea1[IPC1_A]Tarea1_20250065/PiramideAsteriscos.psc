Algoritmo PiramideAsteriscos
	Definir n, i, j, espacios, asteriscos Como Entero
	Definir linea Como Cadena
	Escribir 'Ingrese la cantidad de niveles:'
	Leer n
	Para i<-1 Hasta n Hacer
		espacios <- n-i
		asteriscos <- 2*i-1
		linea <- ''
		// Agregar espacios
		Para j<-1 Hasta espacios Hacer
			linea <- linea+' '
		FinPara
		// Agregar asteriscos
		Para j<-1 Hasta asteriscos Hacer
			linea <- linea+'*'
		FinPara
		Escribir linea
	FinPara
FinAlgoritmo
